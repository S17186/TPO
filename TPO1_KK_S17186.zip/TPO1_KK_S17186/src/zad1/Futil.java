package zad1;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;


public class Futil {

	public static void processDir(String dirName, String resultFileName) {
		
		//tworze sciezki wejscia i wyjscia
		final Path start= Paths.get(dirName);
		final Path dest= Paths.get(dirName+'\\'+resultFileName);
		
		if (Files.isDirectory(start)) {
			
		try {
			//destination file
			if (Files.exists(dest)) {
				Files.delete(dest);
				println("Old destination file deleted. "); 
				println(""); 
			}
			
			//encoder
			final Charset utfset = Charset.forName("UTF-8");
			final CharsetEncoder encoder = utfset.newEncoder();
			//decoder
			final Charset cp1250set = Charset.forName("cp1250");
			final CharsetDecoder decoder = cp1250set.newDecoder();	
			
			//destination channel open, closed after FileVisitor is done
			final FileChannel destination_channel = FileChannel.open(dest, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE); 
			
			//nastepne musze zrobic wewnatrz FileVisitor, zeby miec konkretny plik do odczytu!!
				
			println(); 
			Files.walkFileTree(start, new SimpleFileVisitor<Path>() {
				
			     @Override
			     public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
			         throws IOException
			     {
			    	 if (file.compareTo(dest)==0) {
			    		 println("Skipping this file: It's the destination file itself!!!!"); 
			    		 println(); 
			    		 return FileVisitResult.CONTINUE;
			    	 } 
			    	 println("Loading file: "+file.toString()); 
			    	 //loading file
			    	 final FileInputStream in_stream = new FileInputStream(file.toString()); 
			    	 final FileChannel in_channel = in_stream.getChannel(); 
			    	 final MappedByteBuffer in_buffer = in_channel.map(FileChannel.MapMode.READ_ONLY, 0, in_channel.size()); 
			    	 //decoding
			    	 final CharBuffer decoded_in_char_buffer = decoder.decode(in_buffer); 
			    	 //encoding file
			    	 final ByteBuffer encoded_in_byte_buffer = encoder.encode(decoded_in_char_buffer); 
			    	 //writing to destination file
			    	 destination_channel.write(encoded_in_byte_buffer);
			    	 //closing
			    	 in_channel.close();
			    	 in_stream.close();
			    	 println("Completed!");
			    	 println(); 
			    	 
			         return FileVisitResult.CONTINUE;
			     }
			     @Override
			     public FileVisitResult postVisitDirectory(Path dir, IOException e)
			         throws IOException
			     {			    	     	 
			         if (e == null) {
			        	 println("Done with this directory. "); 
			             println("---");
			             println(); 
			             return FileVisitResult.CONTINUE;
			         }
			          else // directory iteration failed
			             throw e;		     
			     }		     
			});
			
			destination_channel.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} 
		
	} else  {
		final Exception e=new Exception((dirName+" is not a directory. "));
		e.printStackTrace();
	}
		
	}
	
//	---------------------------------------------
	
	public static void println(String txt) {
		System.out.println(txt); 
	}
	public static void println() {
		System.out.println(); 
	}
//	---------------------------------------------	

}
