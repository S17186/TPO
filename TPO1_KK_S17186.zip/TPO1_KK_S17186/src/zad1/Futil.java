package zad1;


import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;


public class Futil {

	public static void processDir(String dirName, String resultFileName)  {
		
		final Path start= Paths.get(dirName);
		final Path dest= Paths.get(resultFileName);
		
		if (Files.isDirectory(start)) {
			

			//encoder
			final Charset utfset = Charset.forName("UTF-8");
			final CharsetEncoder encoder = utfset.newEncoder();
			//decoder
			final Charset cp1250set = Charset.forName("cp1250");
			final CharsetDecoder decoder = cp1250set.newDecoder();	
			
			try {
				//destination channel open, closed after FileVisitor is done
				final FileChannel destination_channel = FileChannel.open(dest, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.CREATE); 	
				println(); 
				Files.walkFileTree(start, new SimpleFileVisitor<Path>() {
					
				     @Override
				     public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
				     try {

				    	 println("Loading file: "+file.toString()); 
				    	 //loading file
				    	 final FileChannel in_channel = FileChannel.open(file); 
				    	 final MappedByteBuffer in_buffer = in_channel.map(FileChannel.MapMode.READ_ONLY, 0, in_channel.size()); 
				    	 //decoding
				    	 final CharBuffer decoded_in_char_buffer = decoder.decode(in_buffer); 
				    	 //encoding file
				    	 final ByteBuffer encoded_in_byte_buffer = encoder.encode(decoded_in_char_buffer); 
				    	 //writing to destination file
				    	 destination_channel.write(encoded_in_byte_buffer);
				    	 //closing
				    	 in_channel.close();
				    	 println("Completed!");
				    	 println(); 
				    	 
				         return FileVisitResult.CONTINUE;
				     } catch (Exception e) {
				    	 e.printStackTrace();
				    }
				    println("Loading or reading file: "+file.toString()+" failed. "); 
					return FileVisitResult.CONTINUE;	 
				     }
				});
				destination_channel.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	} else  {
		final Exception e=new Exception((dirName+" is not a directory. "));
		e.printStackTrace();
	}
		
	}
	
//	---------------------------------------------
	
	public static void println(String txt) {
		System.out.println(txt); 
	}
	public static void println() {
		System.out.println(); 
	}
//	---------------------------------------------	

}
